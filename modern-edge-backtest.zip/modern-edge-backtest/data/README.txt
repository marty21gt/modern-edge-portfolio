Placeholder. The GitHub Actions workflow overwrites this folder with:
  modern_edge_daily_long.csv
  modern_edge_daily_short.csv
  modern_edge_backtest.json
